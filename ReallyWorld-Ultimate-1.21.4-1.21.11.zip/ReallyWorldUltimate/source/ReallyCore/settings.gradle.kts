rootProject.name = "ReallyCore"
