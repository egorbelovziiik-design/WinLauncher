"""Bot cogs package."""
