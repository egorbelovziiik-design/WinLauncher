#!/usr/bin/env bash
set -e
mkdir -p plugins
echo "=== Скачивание чистых официальных плагинов для Новогодней Сборки KINGGRIEF (1.21.x) ==="

dl_modrinth() {
  local slug="$1"
  local out="$2"
  echo " -> $slug..."
  local url
  url=$(curl -fsSL "https://api.modrinth.com/v2/project/${slug}/version" | python3 -c "
import sys, json
vs = json.load(sys.stdin)
for v in vs:
    loaders = [l.lower() for l in v.get('loaders', [])]
    if any(l in loaders for l in ('paper','purpur','spigot','bukkit')):
        for f in v.get('files', []):
            if f['filename'].endswith('.jar'):
                print(f['url']); sys.exit(0)
" 2>/dev/null || true)
  if [ -n "$url" ]; then
    curl -fsSL "$url" -o "plugins/${out}"
  fi
}

dl_modrinth "luckperms" "LuckPerms.jar"
dl_modrinth "tab-was-taken" "TAB.jar"
dl_modrinth "decentholograms" "DecentHolograms.jar"
dl_modrinth "placeholderapi" "PlaceholderAPI.jar"
dl_modrinth "fastasyncworldedit" "FastAsyncWorldEdit.jar"
dl_modrinth "worldguard" "WorldGuard.jar"
dl_modrinth "essentialsx" "EssentialsX.jar"
dl_modrinth "betterrtp" "BetterRTP.jar"
dl_modrinth "viaversion" "ViaVersion.jar"
dl_modrinth "viabackwards" "ViaBackwards.jar"

echo "=== Все базовые плагины загружены в ./plugins/! KingGriefBridge.jar уже встроен. ==="
