# 🎄 Новогодняя Сборка KINGGRIEF v6.0.1 (FunTime × ReallyWorld) + Нейро-Античит **KingАЧ v8.0**

Полностью готовая под ключ сборка: ядро `KingGriefCore.jar` **v6.0.1**, античит `KingAC.jar` **v8.0**
(8 Схем Инжекта + 3D Raycast Хитбокса), сеть Хаб ↔ 1 Гриф (`KingHub.jar` v1.2.0 + `KingConnect.jar` v2.2.0),
`KingClear.jar` v1.0.1, Мега-Ресурспак и облачная синхронизация с сайтом **https://kinggrief.vercel.app**.

---

## ⚡ БЫСТРЫЙ СТАРТ (3 шага)

1. Распакуйте `rw-newyear-full-assembly.zip` — внутри **плоская структура**: `plugins/`, `resourcepack/`,
   `start-server.sh`, `server.properties`, `spigot.yml`, `TechWorksStub.jar`.
2. Скопируйте **всё содержимое архива в корень вашего сервера** (папка, где лежит `paper.jar` / `purpur.jar`).
   Главный файл античита должен оказаться здесь: **`plugins/KingAC.jar`**.
3. Перезапустите сервер. В консоли появится:

```
[KingAC] ==================================================================
[KingAC]  KingAC v8.0 - PROFESSIONAL NEURAL ANTI-CHEAT ENABLED
[KingAC]  * 8 LIVE INJECTION SCHEMES (360 / WALL / ORBIT / ZENITH / SWARM
[KingAC]  * Commands: /ac /kac /kingac /inject /report /reports
```

---

## 🛡 ГЛАВНОЕ: ЧТОБЫ АНТИЧИТ ТОЧНО РАБОТАЛ В ПАПКЕ `plugins/`

| Проверьте | Как должно быть |
|---|---|
| Файл лежит в `plugins/` | `plugins/KingAC.jar` (ровно так, в корне папки плагинов, **не** в подпапке) |
| Старый античит удалён | Файла `plugins/King_antisoft.jar` быть **не должно** (иначе два античита конфликтуют) |
| Версия ядра | Spigot / Paper / Purpur **1.16.5 – 1.21.x** (`api-version: '1.16'` — плагин грузится везде) |
| Java | Java 8+ для 1.16.5, Java 17+ для 1.18+, Java 21 для 1.20.5+ |
| Перезапуск | После добавления `.jar` нужен **полный рестарт**, `/reload` не подходит |
| Команда в игре | `/ac` → откроется центр детектов (для состава и OP) |

**Команда «не найдена»?** Наберите в игре `/ac status` или `/kingac` — если ответа нет, откройте
`latest.log` и найдите строку `KingAC`. Причина почти всегда одна из трёх:
файл не в `plugins/`, рядом лежит старый `King_antisoft.jar`, или сервер запущен без рестарта.

---

## 🎮 КОМАНДЫ KingАЧ v8.0

### Для всех игроков
| Команда | Действие |
|---|---|
| `/report <ник>` | Жалоба на читера (открывает GUI выбора причины) |
| `/жалоба <ник>`, `/репорт <ник>` | Русские алиасы жалобы |
| `/ac` | Информация об античите + как пожаловаться |

### Для состава (мл. модер+, OP, `kingac.staff`)
| Команда | Действие |
|---|---|
| `/ac` или `/kac` или `/kingac` или `/ач` или `/античит` или `/кингач` | Центр детектов: подозреваемые, VL, настройки |
| `/ac inject` | **GUI выбора цели** для схем инжекта |
| `/ac inject <ник>` | **GUI выбора одной из 8 схем** для игрока |
| `/ac inject <ник> <схема>` | Запуск схемы: `back wall orbit zenith swarm hitbox backtrack cascade auto all` |
| `/inject`, `/инжект`, `/схемы` | Быстрый вход в схемы инжекта |
| `/ac schemes` | Вкл/выкл модулей всех 8 схем + авто-прогон |
| `/ac monitor <ник>` | **Живой HUD в ActionBar**: VL, CPS, пинг, схема, последний детект (повторно — выкл.) |
| `/ac top` | Топ-10 подозреваемых по VL |
| `/ac checks` | Полный список всех проверок античита |
| `/ac status` | Статистика сессии (детекты, фантомы, авто-баны, жалобы) |
| `/ac log` | Последние записи `plugins/KingAC/detections.log` |
| `/ac info <ник>` | Нейро-досье: VL по проверкам, микро-дёргания, попадания по фантомам |
| `/ac probe <ник> [схема]` | Быстрый инжект (Спина-360° + Сквозь-Стену) |
| `/ac ban <ник> [причина]`, `/ac unban <ник>` | Авто-бан / разбан силами KingАЧ |
| `/ac alerts` | Вкл/выкл алерты в чате |
| `/reports` | GUI активных жалоб |

---

## 💉 8 СХЕМ ИНЖЕКТА (новое в v8.0)

Схемы спавнят **невидимых микро-фантомов** в точки, куда честный клиент физически не может
отправить пакет атаки. Любой чит-клиент бьёт по ним — и мгновенно получает детект и VL.

| # | ID | Схема | Что ловит |
|---|---|---|---|
| 1 | `back` | Спина-360° | Rage/KillAura на 360° (фантом следует за затылком 20 тиков) |
| 2 | `wall` | Сквозь-Стену | WallHit / удары сквозь стекло Трапки, Пласт, кабинки |
| 3 | `orbit` | Орбита-Вихрь | AimLock / AimBot-магнит (фантом кружится 28°/тик) |
| 4 | `zenith` | Верхний Купол +85° | SilentAura / MultiPoints (цель над макушкой вне экрана) |
| 5 | `swarm` | Мульти-Рой x4 | MultiAura / SwitchAura (4 фантома во всех слепых зонах) |
| 6 | `hitbox` | Байт-Хитбокс | HitBoxes (+0.5…+2.0) / SilentAim / удары в воздух |
| 7 | `backtrack` | Призрак-Отступ | Reach + Backtrack (фантом отпрыгивает на 4.2 м) |
| 8 | `cascade` | Каскад «Полный Нейро-Скан» | Прогон всех 7 схем подряд с отчётом в чат и ActionBar |

Авто-прогон: KingАЧ сам каждые 3 сек. подбирает схему для игроков под жалобой / Deep Watch / VL > 4.

---

## 🧠 ВСЕ ПРОВЕРКИ v8.0

**Бой:** KillAura (360° / Мульти / в GUI / со щитом-едой / без взмаха руки), Reach, HitBoxes,
SilentAura, Backtrack, WallAura (13-лучевой RayTrace), **TriggerBot**, AutoClicker (CPS + макрос + **куртозис**),
Criticals (пакет-крит + **микро-хоп**), KeepSprint, AimBot, Aim (микро-дёргание / GCD / горизонт-лок), FastBow.

**Движение:** Fly, AirJump, Speed/Bhop, AirStrafe, Jesus, NoSlow, **Phase (NoClip)**, **AntiKB (вертикаль + горизонталь)**,
**Timer/Blink (баланс move-пакетов)**, Step.

**Мир и инвентарь:** Scaffold, **FastPlace**, **GuiMove (ИнвХод)**, AutoTotem, XRay (скрытые жилы).

**Точный 3D Raycast Хитбокса** — ядро v7.0 сохранено полностью: игрок должен бить **в игрока, а не в воздух**,
удары мимо модели (HitBox / SilentAura / Backtrack) **не регистрируются вообще**, история хитбоксов жертвы
хранится 18 тиков с пинг-компенсацией до 560 мс.

---

## ⚙ ФАЙЛЫ И НАСТРОЙКИ

```
plugins/KingAC.jar                <- сам античит v8.0
plugins/KingAC/config.yml         <- пороги VL, авто-бан, setback, вкл/выкл каждой из 8 схем
plugins/KingAC/bans.yml           <- база авто-банов KingАЧ
plugins/KingAC/detections.log     <- полный лог детектов (время, проверка, игрок, VL, пинг, схема)
```

Ключи `config.yml`: `settings.auto-ban-enabled`, `settings.auto-ban-vl` (18),
`settings.auto-ban-duration-seconds` (30 дней), `settings.movement-setback-enabled`,
`settings.micro-head-twitch-check`, `settings.ray-hitbox-air-block`, `settings.auto-inject-schemes`,
`settings.max-autoban-ping-ms` (420), `settings.report-cooldown-seconds` (25),
`schemes.back/wall/orbit/zenith/swarm/hitbox/backtrack/cascade`.

---

## 📦 СОСТАВ СБОРКИ

| Файл | Версия | Назначение |
|---|---|---|
| `plugins/KingAC.jar` | **8.0.0** | Нейро-античит KingАЧ + 8 Схем Инжекта (1.16.5–1.21.x) |
| `plugins/KingGriefCore.jar` | **6.0.1** | Ядро: ранги, киты, кейсы, /tm, /duel, Божья Аура, модерация, мост KingАЧ |
| `plugins/KingClear.jar` | 1.0.1 | Отдельный `/clear` |
| `plugins/KingGriefBridge.jar` | 2.x | Облачный мост на сайт kinggrief.vercel.app |
| `plugins/KingConnect.jar` | 2.2.0 | Сервер 1 Гриф: приём переходов из Хаба |
| `KingHub.jar` | 1.2.0 | Хаб: новогодняя карта, компас, НПС (ставится **в папку Хаба**) |
| `resourcepack/` | v6.0 | Мега-РП (115+ 3D предметов) |
| `TechWorksStub.jar` | 1.0 | Заглушка `⚙ Тех работы!` |

---

## ☁ САЙТ И ОБЛАКО

* Сайт и админ-панель: **https://kinggrief.vercel.app** (`/admin`: `admin` / `KingGrief-2026`)
* Прямые ссылки: `https://kinggrief.vercel.app/KingAC.jar`, `/KingGriefCore.jar`, `/rw-newyear-full-assembly.zip`
* Discord: **https://discord.gg/7Cugj4X3eU**
