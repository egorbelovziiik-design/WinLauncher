# ❄️ ФУЛЛ НОВОГОДНЯЯ СБОРКА KINGGRIEF / REALLYWORLD (1.16.5 — 1.21.11)

Полностью готовая зимняя сборка в стиле **ReallyWorld** без вирусов и бэкдоров, настроенная под ваш сервер **`kinggrief.pickme.cloud`** и магазин **`https://kinggrief.vercel.app`**.

## Что входит в сборку
1. **Готовый 3D Новогодний Спавн (`rw_newyear_spawn.schem`, 121×58×121 блоков):**
   - Огромная новогодняя ёлка 35 блоков со звездой, гирляндами и подарками;
   - 14 подиумов со всеми NPC;
   - Северная Арена Кейсов с 11 пьедесталами под все 11 кейсов вашего сайта;
   - Южный Зимний Колизей PvP (прыжок вниз за красную линию) + 3 кабинки `Kabinka1`, `Kabinka2`, `Kabinka3` 1х1;
   - Кузница и чаровальня 30 уровня.
2. **Все 14 рабочих NPC (`plugins/Citizens/saves.yml`):**
   - Дед Мороз (`/nyshop`), Снегурочка (`/gifts`), Гринч, РТП (`/rtp`), Донат-Магазин (`/shop`), Аукцион (`/ah`), Скупщик (`/buyer`), Работы (`/jobs`), Кланы (`/clan`), Кузнец, Бесплатный донат (`/free`), PvP-Гладиатор, Джамшут (`/kits`), Хранитель Кейсов (`/donate`).
3. **29 готовых Голограмм (`plugins/DecentHolograms/holograms/`):**
   - Главная новогодняя голограмма, PvP-колизей, Кабинки 1х1, Топ убийц, Топ богачей, все 14 NPC и все 11 кейсов.
4. **7 готовых Новогодних Меню (`plugins/DeluxeMenus/`):**
   - `/shop` (Сфера Андромеды, Талисман Крушителя, Трапки, Пласты, Божья Аура за рилики), `/nyshop` (Лавка Деда Мороза), `/gifts` (`/free`), `/rtp`, `/buyer`, `/kits`, `/donate`.
5. **Зимний TAB + Скорборд + Анимированные префиксы `OWNER` (``) и `CURATOR` с клевером (``).**
6. **Все 16 групп LuckPerms (`plugins/LuckPerms/setup-ranks-commands.txt`) + 5 китов (`Essentials/kits.yml`) + регионы WorldGuard (`spawn`, `pvp_arena`, `kabinka1-3`) + встроенный `KingGriefBridge.jar` + единый ресурспак.**

---

## Быстрая установка на ваш текущий сервер (за 2 минуты)

1. Распакуйте содержимое папки `server/` в корень вашего сервера (где лежит `plugins/`).
   *(Если не хватает каких-то плагинов — запустите `bash download-plugins.sh` или добавьте `DecentHolograms`, `Citizens`, `DeluxeMenus`, `TAB`, `FastAsyncWorldEdit`/`WorldEdit`, `WorldGuard`, `EssentialsX`, `BetterRTP`).*
2. Перезапустите сервер и зайдите в игру в основной мир `world`.
3. Введите в игре 4 команды для вставки новогоднего спавна ровно по координатам всех NPC и голограмм:
   ```text
   /gamerule randomTickSpeed 0
   /tp 0 100 0
   //schem load rw_newyear_spawn
   //paste -a
   ```
4. Установите точку спавна игроков перед ёлкой:
   ```text
   /tp 0.5 100 14.5 180 0
   /setspawn
   /setworldspawn 0 100 14
   ```
5. Импортируйте группы LuckPerms (скопируйте команды из `plugins/LuckPerms/setup-ranks-commands.txt` в консоль) и обновите плагины:
   ```text
   /dh reload
   /dm reload
   /tab reload
   /citizens reload
   ```
